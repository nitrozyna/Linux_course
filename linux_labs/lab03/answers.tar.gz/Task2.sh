#!/bin/bash

if [ -d "data" ]; then
	echo "There is a file called data."
else
	mkdir ./data
fi

if [ -d "data/processed" ]; then
	echo "There is a file called data/processed."
else
	mkdir ./data/processed
fi

if [ -d "docs" ]; then
	echo "There is a file called docs."
else
	mkdir ./docs
fi
