#!/bin/bash

mkdir ./data
mkdir ./data/processed
mkdir ./docs
