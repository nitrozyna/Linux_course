#!/bin/bash

i="0"

while [ $i -lt 100 ];
do
    echo $((RANDOM%100)) >> random
    let i=i+1
done

