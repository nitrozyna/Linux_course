#!/bin/bash
FAIL=0
for file in *
do
	if [ -d $file ]; then
		FAIL=1
	fi
done

echo $FAIL
if [ $FAIL = 1 ]; then
	echo "Not end of an branch"
else
	echo "end of an branch"
fi 
