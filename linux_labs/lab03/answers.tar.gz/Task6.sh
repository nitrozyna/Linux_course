#!/bin/bash

for file in *.data
do
    echo $file
    if ! [[ -e "$file.bak" ]];then
	echo "$file .bak missing, creating a bak"
	cp $file{,.bak}
    else
	echo "exist"
    fi
done

