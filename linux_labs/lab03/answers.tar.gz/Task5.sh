#!/bin/bash


echo "$@"
for var in "$@"
do
        
	if [ -e $var ]; then
		echo "$var exists"
	else
		echo "$var does not exist"
	fi

done
