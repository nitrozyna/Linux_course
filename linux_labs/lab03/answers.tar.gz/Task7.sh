#!/bin/bash

foldername="$(date +%Y%m%d)"

if [ -e $foldername ]; then
    echo "That directory already exists"
else
    mkdir $foldername
    cd $foldername
    for i in {1..10}
    do
	for i2 in {1..50}
	do
	    echo $((RANDOM%100)) >> random$i.dat
	done
    done
fi
